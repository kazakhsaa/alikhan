<template>
    <div>
      <h1>Home Page</h1>
    </div>
  </template>
  
  <script>
  export default {
    name: 'HomePage',
  };
  </script>
  